package com.zhotel.app.Dao;

import org.springframework.data.repository.CrudRepository;

import com.zhotel.app.Entity.*;

public interface ICategoriasDao extends CrudRepository<Categorias, Long>{

}
