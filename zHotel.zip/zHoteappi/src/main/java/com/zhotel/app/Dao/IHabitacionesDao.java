package com.zhotel.app.Dao;

import org.springframework.data.repository.CrudRepository;

import com.zhotel.app.Entity.*;

public interface IHabitacionesDao extends CrudRepository<Habitaciones,Long>{

}
