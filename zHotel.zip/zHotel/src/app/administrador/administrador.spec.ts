import { Administrador } from './administrador';

describe('Administrador', () => {
  it('should create an instance', () => {
    expect(new Administrador()).toBeTruthy();
  });
});
