export class Administrador {
    idAdmin: number = 0;
    usuario: string = '';
    contrasena: string = '';
    cedula_persona: string = '';
}
