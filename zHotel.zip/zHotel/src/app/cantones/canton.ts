export interface Cantones {
  id_canton: string;
  nombre: string;
  id_provincia: string;
  persona: any[];
}
