import { Component } from '@angular/core';

@Component({
  selector: 'app-carrucel',
  templateUrl: './carrucel.component.html',
  styleUrl: './carrucel.component.css'
})
export class CarrucelComponent {

}
