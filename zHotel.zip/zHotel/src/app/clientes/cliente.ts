export class Cliente {
    idCliente:any;
    usuario: string = '';
    contrasena: string = '';
    cedula_persona: string = '';
    foto: string = '';
}