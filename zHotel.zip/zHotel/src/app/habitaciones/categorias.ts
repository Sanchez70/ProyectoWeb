export class categorias {
      idCategoria: number = 0;
      nombre: string = '';
}