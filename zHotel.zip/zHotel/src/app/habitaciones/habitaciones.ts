export class Habitaciones {
    idHabitaciones: number = 0;
    precio!: number;
    nHabitacion!: number;
    nPiso!: number;
    idCategoria!: number;
    foto: string = '';
    descriphabi: string = '';
    estado: string = '';

}
