export class Login {
  usuario: string = '';
  password: string = '';
}
