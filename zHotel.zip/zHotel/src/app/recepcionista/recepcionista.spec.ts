import { Recepcionista } from './recepcionista';

describe('Recepcionista', () => {
  it('should create an instance', () => {
    expect(new Recepcionista()).toBeTruthy();
  });
});
