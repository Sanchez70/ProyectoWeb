import { Persona } from "../persona/persona";

export class Recepcionista extends Persona {
    idRecepcionista: number = 0;
    usuario: string = '';
    contrasena: string = '';
    sueldo!: number;
    

}
