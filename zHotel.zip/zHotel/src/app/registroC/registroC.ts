
export class RegistroC {
  cedula_persona!: string;
  usuario!: string;
  contrasena!: string;
  foto!: string;
  
}
