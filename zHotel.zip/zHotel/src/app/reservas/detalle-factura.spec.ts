import { DetalleFactura } from './detalle-factura';

describe('DetalleFactura', () => {
  it('should create an instance', () => {
    expect(new DetalleFactura()).toBeTruthy();
  });
});
