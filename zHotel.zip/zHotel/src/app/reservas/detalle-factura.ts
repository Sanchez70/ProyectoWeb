export class DetalleFactura {
    idDetalleFac: number = 0;
    subTotal: number = 0;
    idEncabezado: number = 0;
}
