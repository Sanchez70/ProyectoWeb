import { EncabezadoFactura } from './encabezado-factura';

describe('EncabezadoFactura', () => {
  it('should create an instance', () => {
    expect(new EncabezadoFactura()).toBeTruthy();
  });
});
