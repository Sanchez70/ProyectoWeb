export class EncabezadoFactura {
    idEncabezado: number = 0;
    idCliente: number = 0;
    idReserva: number = 0;
    fechaFactura: Date = new Date();
    total: number = 0;
}
