export class Metodopago {
    idPago: number = 0;
    nombre: string = '';
}
