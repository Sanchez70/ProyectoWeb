import { Reserva } from './reserva';

describe('Reserva', () => {
  it('should create an instance', () => {
    expect(new Reserva()).toBeTruthy();
  });
});
