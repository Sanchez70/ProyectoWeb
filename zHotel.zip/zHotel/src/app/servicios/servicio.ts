export class Servicio {
    idTipo_servicio!: number;
    titulo!: string;
    descripciontipo!: string;
    foto!: string;
}
