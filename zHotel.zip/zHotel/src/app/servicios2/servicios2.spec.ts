import { Servicios2 } from './servicios2';

describe('Servicios2', () => {
  it('should create an instance', () => {
    expect(new Servicios2()).toBeTruthy();
  });
});
