export class Servicios2 {
    idServicio!: number;
    descripcion!: string;
    idHabitaciones!: number;
    idTipo_servicio!: number;
    estado!: string;
}
